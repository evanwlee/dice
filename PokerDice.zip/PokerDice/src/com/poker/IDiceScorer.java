package com.poker;

import java.util.ArrayList;

import com.poker.PokerDiceScorer.ScoreInfo;

public interface IDiceScorer {
	/**
	 * @param rolledDie A collection of 1 or more multi-faced dice
	 * @return ScoreInfo contain data about the wining score
	 * @throws Exception Thrown if the instance cannot handle the dice passed.
	 */
	public ScoreInfo findBestRollType(ArrayList<Die> rolledDie) throws Exception;
}
