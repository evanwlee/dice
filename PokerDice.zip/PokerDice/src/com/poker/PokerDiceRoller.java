package com.poker;

import java.util.*;

import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

import com.poker.test.CustomExecutionListener;
import com.poker.test.PokerTest;

import junit.framework.TestSuite;


/**
 * Main class to roll dice based on user's command line input.
 * Will echo the best score resulting from the roll.
 * 
 * @author evanw
 *
 */
public class PokerDiceRoller{
    public static final int TOTAL_DICE = 5;
    
    //Entry point to roll dice an find best score from command line
    //or
    //run tests
    public static void main(String... args) {
    	
    	String userIn = PokerDiceRoller.readUserInput("Roll the five dice? (Enter Y or y to roll, T or t to run test, anything else to exit)");
    	
    	while("Y".equalsIgnoreCase(userIn) || "T".equalsIgnoreCase(userIn)) {
    		if( "Y".equalsIgnoreCase(userIn) ) {
    			PokerDiceRoller.runDiceGame();
    		}else if("T".equalsIgnoreCase("T")) {
    			PokerDiceRoller.runTests();
    		}
    		userIn = PokerDiceRoller.readUserInput("Roll the five dice? (Enter Y or y to roll, T or t to run test, anything else to exit)");
    	}

    }
    
    //Run JUnit Test and output results
    private static void runTests() {
    	 JUnitCore junitCore = new JUnitCore();
         junitCore.addListener(new CustomExecutionListener());

         Result result = junitCore.run(PokerTest.class);

         for (Failure failure : result.getFailures()) {
            System.out.println(failure.toString());
         }
   		
         System.out.println("");
         System.out.println("");
    	
    }
    
    //run game from command line
    private static void runDiceGame() {
        ArrayList<Die> dice = PokerDiceRoller.rollDice( PokerDiceRoller.TOTAL_DICE );

        //Show roll results
        PokerDiceRoller.printFaces(dice);

        //calculate and print best score
        PokerDiceScorer scorer = new PokerDiceScorer();
        try {
	          scorer.findBestRollType(dice).createMessage();
	          System.out.println(scorer.findBestRollType(dice).createMessage());
        }catch( Exception e) {
      	  //wont happen since we control based on constant
        }
    	
    }

    //Testing harness utility
    //Create dice from know numbers
    public static ArrayList<Die> createKnownDice(int... faces){
      ArrayList<Die> dice = new ArrayList<Die>();
      for (int face : faces) {
        Die die = new Die();
        die.setFaceValue(face);
        dice.add(die);
      }
      return dice;
    }

    /**
     * Create Random Dice
     * 
     * @param numberOfDice
     * @return List of Dice
     */
    public static ArrayList<Die> rollDice(int numberOfDice){
      ArrayList<Die> dice = new ArrayList<Die>();
      for(int i = 0; i < numberOfDice; i++){
        Die die = new Die();
        die.roll();
        dice.add(die);
      }
      return dice;
    }

    /**
     * Output for command line version showing the result of the
     * roll
     * @param dice
     */
    static void printFaces(ArrayList<Die> dice){
    
      StringBuffer rollResult = new StringBuffer("");
      rollResult.append("Player rolls ");
      for (Die currentDie : dice) {
        rollResult.append(currentDie.getFaceValue()).append(", ");
      }
      System.out.print(rollResult.toString().replaceAll(", $", ". "));
    
    }


    /**
     * Utility function to read from the command line
     * 
     * @param prompt - Message echo'd to user with instructions
     * @return the value entered on the command line
     */
    static String readUserInput(String prompt) {
        String inputLine = "";
        System.out.println(prompt);
        try {
          java.io.BufferedReader inputBuffer = new java.io.BufferedReader( new java.io.InputStreamReader(System.in));
          inputLine = inputBuffer.readLine();
        } catch (Exception e) {
          System.out.println("Unable to take input from the command line");
        }
        return inputLine;
      }

}
