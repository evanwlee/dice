package com.poker;

import java.util.*;


/**
 * Dice Score that can handle 5, six-sided dice.
 * 
 * Returns winner info based on the following rules:
 * All Match 50 points,
 * Straight...,
 * Small Straight...,
 * Full...,
 * etc....
 * 
 * Tie will be resolved based on the above sequence
 * 
 * @author evanw
 *
 */
public class PokerDiceScorer implements IDiceScorer{
    int ones = 0, twos = 0, threes = 0, fours = 0, fives = 0, sixes = 0;
    int[] diceFaceValues = null;

    public PokerDiceScorer(){

    }

    //Comment in the interface
    public ScoreInfo findBestRollType(ArrayList<Die> rolledDie) throws Exception{
    	
    	if(rolledDie.size() != 5) {
    		//This scorer only handles 5 dices
    		
    		throw new Exception("Invalid number of dice for this scorer. Only allows 5, six-sided dice.");
    	}
    	  
    	diceFaceValues = this.countFaceTypes(rolledDie);

        //the one case that trumps them all - 
        if( this.areAllTheSame( rolledDie )){
            return new ScoreInfo(ScoreType.SAME, 50);
        }

        ScoreInfo winningScoreInfo = null;

        List<ScoreInfo> allScoreInfo = this.calculateScores(rolledDie);
        //sort by score natural for in...low to high
        allScoreInfo.sort(Comparator.comparingInt(ScoreInfo::getScore));
    
        if (allScoreInfo.size() > 1 ){
            //this assumes no case exist with 3 way tie...
            ScoreInfo lastScore = allScoreInfo.get(allScoreInfo.size()-1) ;
            ScoreInfo nextToLastScore = allScoreInfo.get(allScoreInfo.size()-2) ;

            if(lastScore.getScore() > nextToLastScore.getScore()){
                //A definitive winning score
            	winningScoreInfo = lastScore;
            }else{
                //Resolve TIE based on ORDER defined in enum
                if(lastScore.getTypePriority() > nextToLastScore.getTypePriority()){
                	winningScoreInfo = lastScore ;
                }else{
                	winningScoreInfo = nextToLastScore ;
                }
            }
        }else{
            //Only One so it is the winner
        	winningScoreInfo = allScoreInfo.get(0);
        }

        return winningScoreInfo;
    }
    
    private void resetCounts() {
    	this.ones = 0;
    	this.twos = 0;
    	this.threes = 0; 
    	this.fours = 0;
    	this.fives = 0; 
    	this.sixes = 0;
    }



    /**
     * Primarily for testing ... get all scores based on a set of dice
     * @param rolledDie
     * @return List of all possible scores
     */
    public List<ScoreInfo> calculateScores(ArrayList<Die> rolledDie){
    	if( diceFaceValues == null) {
    		  diceFaceValues = this.countFaceTypes(rolledDie);
    	}
        List<ScoreInfo> info = new ArrayList<ScoreInfo>();

        int score = 0;

        //Determine all Scoring Types
        if ( this.isStraight() ) {
            info.add(new ScoreInfo(ScoreType.STRAIGHT,40));
        } 

        if ( (score = this.isFourOfKind()) > 0) {
            info.add(new ScoreInfo(ScoreType.FOUR,score));
        } 

        if ( (score = this.isThreeOfKind()) > 0) {
            info.add(new ScoreInfo(ScoreType.THREE,score));
        } 
        
        if ( this.isSmallStraight() ) {
            info.add(new ScoreInfo(ScoreType.SMALL,30));
        }

        if ( this.isFullHouse() ) {
            info.add(new ScoreInfo(ScoreType.FULL,25));
        }

        info.add(new ScoreInfo(ScoreType.CHANCE,this.calculateSumOfFaces()));

        return info;
    }

    /**
     * @return true if this the dice make a straight 
     */
    protected boolean isStraight(){
        if ((diceFaceValues[0] == diceFaceValues[1] - 1) &&
            (diceFaceValues[1] == diceFaceValues[2] - 1) && 
            (diceFaceValues[2] == diceFaceValues[3] - 1) && 
            (diceFaceValues[3] == diceFaceValues[4] - 1)) {
            return true;
        }
        return false;
    }

    /**
     * @return true if this the dice make a small straight 
     */
    protected boolean isSmallStraight(){
        if ((ones > 0) && (twos > 0) && (threes > 0) && (fours > 0)) {
            return true;
        } else if ((threes > 0) && (fours > 0) && (fives > 0) && (sixes > 0)) {
            return true;
        } else if ((twos > 0) && (threes > 0) && (fours > 0) && (fives > 0)) {
            return true;
        }

        return false;
    }

    /**
     * @return score based on the face values qualifing as 4 of a kind. It will be 0 if not 4 of a kind.
     * Score is sum of face values plus 10
     */
    protected int isFourOfKind(){
        if ((ones > 3) || (twos > 3) || (threes > 3) || (fours > 3) || (fives > 3) || (sixes > 3)) {
            return 10 + this.calculateSumOfFaces();
        }

        return 0;
    }

    /**
     * @return score based on the face values qualifing as 3 of a kind. It will be 0 if not 3 of a kind.
     * Score is sum of face values plus 5
     */
    protected int isThreeOfKind(){
        if ((ones > 2) || (twos > 2) || (threes > 2) || (fours > 2) || (fives > 2) || (sixes > 2)) {
            return 5 + this.calculateSumOfFaces();
        }

        return 0;
    }

    /**
     * @return true if this the dice make a full house 
     */
    protected boolean isFullHouse(){
        if (((ones == 2) || (twos == 2) || (threes == 2) || (fours == 2) || (fives == 2) || (sixes == 2)) &&
            ((ones == 3) || (twos == 3) || (threes == 3) || (fours == 3) || (fives == 3) || (sixes == 3))){
            return true;
        }

        return false;
    }
    
    /**
     * @param rolledDie List of 5 dice
     * @return true if all the dice faces are the same
     */
    public Boolean areAllTheSame(ArrayList<Die> rolledDie){
        int[] diceFaceValuesArr = Arrays.stream(rolledDie.toArray()).mapToInt(item -> ((Die)item).getFaceValue()).toArray();
        for(int i = 0; i < diceFaceValuesArr.length-1; i++){
            if(diceFaceValuesArr[i] != diceFaceValuesArr[i+1]){
                return false;
            }
        }
        return true;
    }

    //Determine the total sum of all faces
    //used be interanal scoring
    private int calculateSumOfFaces(){

        int sum = 0;

        if ( ones > 0 ){
            sum = ones;
        }
        if ( twos > 0 ){
            sum = sum + (twos * 2);
        }
        if ( threes > 0 ){
            sum = sum + (threes * 3);
        }
        if ( fours > 0 ){
            sum = sum + (fours * 4);
        }
        if ( fives > 0 ){
            sum = sum + (fives * 5);
        }
        if ( sixes > 0 ){
            sum = sum + (sixes * 6);
        }
         
        return sum;

    }

    //track how many of each face type this list of die contains
    //used for higher level calulations
    private int[] countFaceTypes(ArrayList<Die> rolledDie){
    	this.resetCounts();
        int i = 0;
        int[] diceFaceValuesArr = new int[rolledDie.size()];
        for (Die die : rolledDie) {
            diceFaceValuesArr[i++] = die.getFaceValue();
        }

    
        //Establish the counts
        for (int y = 0; y < 5; y++) {
            if (diceFaceValuesArr[y] == 1) {
                this.ones++;
            }
            if (diceFaceValuesArr[y] == 2) {
                this.twos++;
            }
            if (diceFaceValuesArr[y] == 3) {
                this.threes++;
            }
            if (diceFaceValuesArr[y] == 4) {
                this.fours++;
            }
            if (diceFaceValuesArr[y] == 5) {
                this.fives++;
            }
            if (diceFaceValuesArr[y] == 6) {
                this.sixes++;
            }
        }

        return diceFaceValuesArr;
    }


    /**
     * Class for holding score info.
     * 
     * Total Score
     * Score Type
     * Score Message
     * 
     * @author evanw
     *
     */
    public class ScoreInfo{
        public ScoreInfo(ScoreType type, int score){
            this.totalScore = score;
            this.type = type;
        }
        private int totalScore = 0;
        private ScoreType type;

        public int getScore(){
            return this.totalScore;
        }

        /**
         * @return ScoreType enum value based on what this score is
         */
        public ScoreType getType(){
            return this.type;
        }

        /**
         * @return ordering priority to be used to resolve ties
         */
        public int getTypePriority(){
            return this.type.getPriority();
        }
        
        /**
         * @return printable message with information about the score type and points
         */
        public String createMessage(){
            return "The best roll type in this case would be " + this.getType().print()+ " ("+this.getScore()+" points)";
        }

    }

    /**
     * Enum of allowed scoring types for this scorer.
     * 
     * @author evanw
     *
     */
    public enum ScoreType {
    	SAME("Same",7),
        STRAIGHT("Straight",6), 
        SMALL("Small Straight",5), 
        FULL("Full House",4),
        FOUR("Four of a kind",3),
        THREE("Three of a kind",2),
        CHANCE("Chance",1);
       
        private String desc = new String("");
        private int priority = 1;
        
        private String message = new String("");
        
        /**
         * @param description text description used in message
         * @param priority used in case of a tie to determine winner
         */
        ScoreType(String description, int priority){
            this.desc = description;
            this.priority = priority;
        }

        public String print(){
            return this.desc;
        }

        public int getPriority(){
            return this.priority;
        }
        
    }
    
}
