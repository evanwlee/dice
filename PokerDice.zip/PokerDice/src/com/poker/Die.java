package com.poker;

import java.util.Random;


/**
 * Represents a dice with face value of 1-6.
 * 
 * 
 * @author evanw
 *
 */
public class Die {
    private int faceValue = 0;
    private static final Random randomFaceValueGenerator = new Random();
   
    public Die() {
    }
   
    /** 
     * Generates a random 'face value' from 1-6 
     */
    public void roll() {
        this.setFaceValue(this.faceValue = 1 + randomFaceValueGenerator.nextInt(6));
    }
   
    /** 
     * @return int A number from 1-6
     */
    public int getFaceValue() {
      return this.faceValue;
    }

    /**
     * Print the face value to command line
     */
    public void printFaceValue(){
        System.out.print(this.getFaceValue());
    }

    /**
     * handle validation, exposed only for testing
     * @param val the face value
     */
    public void setFaceValue(int val) {
        if( val > 0 && val < 7){
            this.faceValue = val;
        }
    }
  }
