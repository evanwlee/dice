package com.poker.test;


import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.poker.Die;
import com.poker.PokerDiceRoller;
import com.poker.PokerDiceScorer;
import com.poker.PokerDiceScorer.ScoreInfo;
import com.poker.PokerDiceScorer.ScoreType;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

public class PokerTest {


	    @Test                                               
	    public void testFiveOfKind() throws Exception{
	    	PokerDiceScorer scorer =new PokerDiceScorer();
	        ArrayList<Die> dice = PokerDiceRoller.createKnownDice(5,5,5,5,5);

	        assertEquals( scorer.findBestRollType(dice).getType(),  PokerDiceScorer.ScoreType.SAME);
	    }
	    
	    @Test                                               
	    public void testStraigh() throws Exception{
	    	PokerDiceScorer scorer =new PokerDiceScorer();
	        ArrayList<Die> dice = PokerDiceRoller.createKnownDice(1,2,3,4,5);

	        assertEquals( scorer.findBestRollType(dice).getType(), PokerDiceScorer.ScoreType.STRAIGHT);
	    }
	    
	    @Test                                               
	    public void testShortStraigh() throws Exception{
	    	PokerDiceScorer scorer =new PokerDiceScorer();
	        ArrayList<Die> dice = PokerDiceRoller.createKnownDice(1,2,3,4,3);
	        assertEquals( scorer.findBestRollType(dice).getType(), PokerDiceScorer.ScoreType.SMALL);
	    }
	    
	    @Test                                               
	    public void testFullHouste() throws Exception{
	    	PokerDiceScorer scorer =new PokerDiceScorer();
	        ArrayList<Die> dice = PokerDiceRoller.createKnownDice(2,2,2,1,1);
	        assertEquals( scorer.findBestRollType(dice).getType(), PokerDiceScorer.ScoreType.FULL);
	    }
	    
	    @Test                                               
	    public void testFourOfKind() throws Exception{
	    	PokerDiceScorer scorer =new PokerDiceScorer();
	        ArrayList<Die> dice = PokerDiceRoller.createKnownDice(1,1,1,1,2);
	        assertEquals( scorer.findBestRollType(dice).getType(), PokerDiceScorer.ScoreType.FOUR);
	    }
	    
	    @Test                                               
	    public void testThreeOfKind() throws Exception{
	    	PokerDiceScorer scorer =new PokerDiceScorer();
	        ArrayList<Die> dice = PokerDiceRoller.createKnownDice(3,3,3,1,2);
	        assertEquals( scorer.findBestRollType(dice).getType(), PokerDiceScorer.ScoreType.THREE);
	    }
	    
	    @Test                                               
	    public void testChance() throws Exception{
	    	PokerDiceScorer scorer =new PokerDiceScorer();
	        ArrayList<Die> dice = PokerDiceRoller.createKnownDice(1,1,2,2,3);
	        assertEquals( scorer.findBestRollType(dice).getType(), PokerDiceScorer.ScoreType.CHANCE);
	    }
	    
	    @Test                                               
	    public void testTieGoesToHigherThreeVsFull() throws Exception{
	    	//
	    	PokerDiceScorer scorer =new PokerDiceScorer();
	        ArrayList<Die> dice = PokerDiceRoller.createKnownDice(6,6,6,1,1);
	        assertEquals( scorer.findBestRollType(dice).getType(), PokerDiceScorer.ScoreType.FULL);
	    }
	    
	    @Test                                               
	    public void testThreeWinOverFull() throws Exception{
	    	PokerDiceScorer scorer =new PokerDiceScorer();
	        ArrayList<Die> dice = PokerDiceRoller.createKnownDice(6,6,6,2,2);
	        assertEquals( scorer.findBestRollType(dice).getType(), PokerDiceScorer.ScoreType.THREE);
	    }
	    
	    @Test                                               
	    public void testFullOverThree() throws Exception{
	    	PokerDiceScorer scorer =new PokerDiceScorer();
	        ArrayList<Die> dice = PokerDiceRoller.createKnownDice(3,3,3,2,2);
	        assertEquals( scorer.findBestRollType(dice).getType(), PokerDiceScorer.ScoreType.FULL);
	    }
	    
	    @Test                                               
	    public void testHasScore() {
	    	PokerDiceScorer scorer =new PokerDiceScorer();
	        ArrayList<Die> dice = PokerDiceRoller.createKnownDice(1,1,2,2,2);
	        List<PokerDiceScorer.ScoreInfo> scores = scorer.calculateScores(dice);
	        assertNotEquals(0, scores.size());
	    }
	    
	    @Test                                               
	    public void testHasScoreTooManyDice() {
	    	PokerDiceScorer scorer =new PokerDiceScorer();
	        ArrayList<Die> dice = PokerDiceRoller.createKnownDice(1,1,2,2,2,6);
	        List<PokerDiceScorer.ScoreInfo> scores = scorer.calculateScores(dice);
	        assertNotEquals(0, scores.size());
	    }
	    
	    @Test                                               
	    public void testAllTheSame() throws Exception{
	    	PokerDiceScorer scorer =new PokerDiceScorer();
	        ArrayList<Die> dice = PokerDiceRoller.createKnownDice(1,1,1,1,1);
	        assertEquals(true,scorer.areAllTheSame(dice).booleanValue());
	    }
	    
	    @Test                                               
	    public void testValidScore() throws Exception {
	    	PokerDiceScorer scorer =new PokerDiceScorer();
	        ArrayList<Die> dice = PokerDiceRoller.createKnownDice(6,6,6,2,2);
	        assertEquals( scorer.findBestRollType(dice).getScore(), 27);
	    }
	    @Test  
	    public void testValidScoreOverManyRandomRolls() throws Exception {
	    	for(int i = 0; i< 100; i++) {
	    		PokerDiceScorer scorer =new PokerDiceScorer();
		        ArrayList<Die> dice = PokerDiceRoller.rollDice(5);
		        assertNotEquals( scorer.findBestRollType(dice).getScore(), 0);
	    	}
	    }
	    

	    @Test 
	     public void testRollDiceReturnsFive() {
	    	 ArrayList<Die> dice = PokerDiceRoller.rollDice(5);
	         assertEquals(5, dice.size());
	     }
	    
	    @Test 
	     public void testRollDiceReturnsSix() {
	    	 ArrayList<Die> dice = PokerDiceRoller.rollDice(6);
	         assertEquals(6, dice.size());
	     }
}
