Evan Lee's submission for the Poker Dice program

To Run:
1) Unzip the file into directory of your choice
2) In that directory, rename PokerDice.j.runable to PokerDice.jar
3) Open a terminal, change to directory containing the jar
4) Run: java -jar PokerDice.jar (using JRE 1.8 or higher)

The console will prompt for input.

Choices: 
Y|y = Role and get best score
T|t = Run unit tests
Other = exit


Notes:
1) Normally the Unit Test would be in separate directory, but I have all code in one
for ease of review.
